<?php
require_once $base_link . "/base_de_datos/conexion.php";
session_start();

// Manejo de login antes de enviar cualquier salida al navegador
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["button-enviar-registro"])) {
    $correo = $conn->real_escape_string($_POST["correo_modal"]);
    $pass   = $conn->real_escape_string($_POST["pass_modal"]);

    $consulta = "SELECT * FROM usuarios WHERE email = '$correo' AND password = '$pass'";
    $result   = $conn->query($consulta);

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $_SESSION["id_usuario"]      = $row["id_usuario"];
        $_SESSION["correo"]          = $row["email"];
        $_SESSION["nombre"]          = $row["nombre"];
        $_SESSION["apellido_paterno"] = $row["apellido_paterno"];
        $_SESSION["dni"]             = $row["dni"];
        $_SESSION["celular"]         = $row["celular"];
        $_SESSION["rango"]           = $row["rango"];

        // Redirección según rango
        if ($row["rango"] === "0") {
            header("Location: {$link_base_root}/index.php");
            exit;
        } else {
            header("Location: {$link_base_root}/../../Panel/index.php");
            exit;
        }
    } else {
        header("Location: {$link_base_root}/index.php");
        exit;
    }
}
?>

<header class="header-1">
    <div class="contenedor-menu-1">
        <div class="contenedor-logo-imagen">
            <a href="<?php echo $link_base_root ?>/index.php">
                <img src="<?php echo $link_base_root ?>/imagenes_banner/logo_pagina_principal.png" alt="logo de la página">
            </a>
            <div class="container-button-togle-menu">
                <button><i class="fas fa-align-justify"></i></button>
            </div>
        </div>

        <form action="<?php echo $link_base_root ?>/busqueda/busqueda.php" class="contenedor-buscador-input" method="get">
            <input type="text" placeholder="Buscar productos de tu preferencia" name="search">
            <button class="icon-buscador">
                <i class="fas fa-search"></i>
            </button>
        </form>

        <nav class="container-nav-icons-header-1">
            <ul>
                <?php if (isset($_SESSION["correo"])): ?>
                    <li class="item-menu cuenta-activa">
                        <a href="<?php echo $link_base_root ?>/usuario/usuario_cuenta.php">
                            <i class="fas fa-user"></i> <?php echo $_SESSION["nombre"]; ?>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="item-menu ingresar-cuenta">
                        <span><i class="fas fa-user"></i></span> Ingresar
                    </li>
                <?php endif; ?>

                <li class="item-menu">
                    <a href="<?php echo $link_base_root ?>/producto/carrito_productos.php" class="item-link">
                        <span><i class="fas fa-shopping-cart"></i></span> Mi carrito
                        <?php if (isset($_SESSION["carrito"]) && count($_SESSION["carrito"]) > 0): ?>
                            <span id="cantidad-productos-carrito"><?php echo count($_SESSION["carrito"]); ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</header>

<header class="header-2">
    <nav>
        <ul>
            <?php
            $seccion_header = "SELECT DISTINCT nombre_categoria FROM categoria";
            $secciones      = $conn->query($seccion_header);
            if ($secciones && $secciones->num_rows > 0) {
                while ($row = $secciones->fetch_assoc()) {
                    echo "<li class='item-menu-2'><a href='{$link_base_root}/secciones/productos_seccion.php?categoria=" . urlencode($row['nombre_categoria']) . "' class='item-link-2'>" . htmlspecialchars($row['nombre_categoria']) . "</a></li>";
                }
            } else {
                echo "<li>No tenemos resultados</li>";
            }
            ?>
        </ul>
    </nav>
</header>

<?php if (!isset($_SESSION["correo"])): ?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" autocomplete="on">
    <div class="contenedor-global-modal desactivo">
        <div class="contenedor-registro-ventana-modal">
            <div class="contenedor-modal-icon">
                <i class="fas fa-user"></i>
            </div>
            <div class="contenedor-modal-titulo">
                <h3>Ingresar a mi cuenta</h3>
            </div>
            <div class="contenedor-modal-correo">
                <span><i class="fas fa-at"></i></span>
                <input type="text" class="input_registro_usuario_modal" name="correo_modal" placeholder="Correo" required>
            </div>
            <p class="mensaje-error-modal">Email inválido</p>
            <div class="contenedor-modal-pass">
                <span><i class="fas fa-lock"></i></span>
                <input type="password" class="input_registro_usuario_modal" name="pass_modal" placeholder="Contraseña" required>
            </div>
            <p class="mensaje-error-modal">Contraseña inválida</p>
            <div class="contenedor-modal-botonEnviar">
                <button type="submit" name="button-enviar-registro">Ingresar</button>
            </div>
            <div class="contenedor-modal-link">
                <a href="<?php echo $link_base_root ?>/usuario/registrar_usuario.php">¿No tienes una cuenta?</a>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>
