<?php
    include ("php/head.php");
    echo "<link rel='stylesheet' href=".$link_base_root."/estilos/estilo-slider.css>";
    echo "<link rel='stylesheet' href=".$link_base_root."/estilos/estilo-main.css>";
    include ("php/header.php");
    include ("slider/slider_imagenes.php");
    include ("php/main.php");
    include ("php/footer.php");
?>