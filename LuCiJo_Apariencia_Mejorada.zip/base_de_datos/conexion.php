<?php
$servername = "localhost";
$username = "root";
$password = "";
$base_datos = "tienda_online_rios";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $base_datos);

// Verificar conexión antes de usar el objeto
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Establecer codificación si la conexión fue exitosa
$conn->set_charset("utf8");
?>
